package com.example.smartorder.model.callback;

import com.example.smartorder.model.table.Table;

public interface CallbackTalble {
    public void getTable(Table table);
}
