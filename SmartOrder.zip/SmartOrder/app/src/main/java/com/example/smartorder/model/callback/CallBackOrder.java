package com.example.smartorder.model.callback;

public interface CallBackOrder {
}
