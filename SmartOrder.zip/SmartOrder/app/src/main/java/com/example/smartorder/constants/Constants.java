package com.example.smartorder.constants;

public class Constants {
    public static final String URL = "http://103.143.208.133:2000/api/";
    public static final String LINK = "http://103.143.208.133:2000";
    public static String TOKEN = "";
    public static String NameUser = "";
    public static String AvatarUser = "";
    public static String fragmentListFood = "fragment_list_food";

}
